/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

/**
 *
 * @author Ahmad
 */
public interface Ilogin {
    
    
   public int login(int id,String pass);
   public boolean SignUp(String name,String password,int age,int id);
 
 
 
 
 
}
